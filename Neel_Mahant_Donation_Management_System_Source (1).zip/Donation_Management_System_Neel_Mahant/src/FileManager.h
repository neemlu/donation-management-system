#pragma once
#include "Entities.h"
#include <string>
#include <vector>

class FileManager {
public:
    explicit FileManager(std::string directory = "data");
    bool save(const std::vector<Donor>& donors, const std::vector<Campaign>& campaigns,
              const std::vector<Donation>& donations, const std::vector<Beneficiary>& beneficiaries) const;
    bool load(std::vector<Donor>& donors, std::vector<Campaign>& campaigns,
              std::vector<Donation>& donations, std::vector<Beneficiary>& beneficiaries) const;
private:
    std::string directory_;
};
