#include "DonationSystem.h"
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>

DonationSystem::DonationSystem() : files_("data") {
    files_.load(donors_, campaigns_, donations_, beneficiaries_);
    for (const auto& x : donors_) nextDonorId_ = std::max(nextDonorId_, x.id + 1);
    for (const auto& x : campaigns_) nextCampaignId_ = std::max(nextCampaignId_, x.id + 1);
    for (const auto& x : donations_) nextDonationId_ = std::max(nextDonationId_, x.id + 1);
    for (const auto& x : beneficiaries_) nextBeneficiaryId_ = std::max(nextBeneficiaryId_, x.id + 1);
    seedIfEmpty();
}
void DonationSystem::seedIfEmpty() {
    if (campaigns_.empty()) campaigns_.emplace_back(nextCampaignId_++, "Community Education Fund", 50000.0, 0.0);
}
int DonationSystem::readInt(const std::string& prompt) const {
    while (true) { std::cout << prompt; int x; if (std::cin >> x) { std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); return x; }
        std::cout << "Invalid integer. Try again.\n"; std::cin.clear(); std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); }
}
double DonationSystem::readAmount(const std::string& prompt) const {
    while (true) { std::cout << prompt; double x; if (std::cin >> x && x > 0) { std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); return x; }
        std::cout << "Enter a valid amount greater than zero.\n"; std::cin.clear(); std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); }
}
std::string DonationSystem::readLine(const std::string& prompt) const { std::cout << prompt; std::string s; std::getline(std::cin, s); return s; }
Donor* DonationSystem::findDonor(int id) { for (auto& x : donors_) if (x.id == id) return &x; return nullptr; }
Campaign* DonationSystem::findCampaign(int id) { for (auto& x : campaigns_) if (x.id == id) return &x; return nullptr; }
void DonationSystem::displayPolymorphic(const Displayable& item) const { item.display(); }

void DonationSystem::run() {
    bool running = true;
    while (running) {
        std::cout << "\n=== DONATION MANAGEMENT SYSTEM ===\n1. Add Record\n2. Display Records\n3. Search Record\n4. Update Record\n5. Delete Record\n6. Record Donation (Main Transaction)\n7. Report\n8. Save / Load\n9. Exit\n";
        int choice = readInt("Choose an option: ");
        try {
            switch (choice) {
                case 1: addRecord(); break; case 2: displayRecords(); break; case 3: searchRecord(); break;
                case 4: updateRecord(); break; case 5: deleteRecord(); break; case 6: recordDonation(); break;
                case 7: report(); break; case 8: saveLoad(); break;
                case 9: if (files_.save(donors_,campaigns_,donations_,beneficiaries_)) std::cout << "Data saved. Goodbye!\n"; else std::cout << "Warning: save failed.\n"; running=false; break;
                default: std::cout << "Choose a number from 1 to 9.\n";
            }
        } catch (const std::exception& e) { std::cout << "Operation failed: " << e.what() << '\n'; }
    }
}
void DonationSystem::addRecord() {
    std::cout << "Add: 1 Donor, 2 Campaign, 3 Beneficiary\n"; int type=readInt("Record type: ");
    if(type==1){ auto n=readLine("Donor name: "); auto p=readLine("Phone: "); if(n.empty()) throw std::invalid_argument("Name cannot be empty."); donors_.emplace_back(nextDonorId_++,n,p); std::cout<<"Donor added. ID "<<donors_.back().id<<'\n'; }
    else if(type==2){ auto n=readLine("Campaign name: "); double t=readAmount("Target amount (Rs): "); if(n.empty()) throw std::invalid_argument("Campaign name cannot be empty."); campaigns_.emplace_back(nextCampaignId_++,n,t); std::cout<<"Campaign added. ID "<<campaigns_.back().id<<'\n'; }
    else if(type==3){ auto n=readLine("Beneficiary name: "); auto need=readLine("Need / purpose: "); if(n.empty()) throw std::invalid_argument("Name cannot be empty."); beneficiaries_.emplace_back(nextBeneficiaryId_++,n,need); std::cout<<"Beneficiary added. ID "<<beneficiaries_.back().id<<'\n'; }
    else std::cout<<"Unknown record type.\n";
}
void DonationSystem::displayRecords() const {
    std::cout<<"\n-- Donors --\n"; if(donors_.empty()) std::cout<<"None\n"; for(const auto& x:donors_) displayPolymorphic(x);
    std::cout<<"-- Campaigns --\n"; if(campaigns_.empty()) std::cout<<"None\n"; for(const auto& x:campaigns_) displayPolymorphic(x);
    std::cout<<"-- Donations --\n"; if(donations_.empty()) std::cout<<"None\n"; for(const auto& x:donations_) displayPolymorphic(x);
    std::cout<<"-- Beneficiaries --\n"; if(beneficiaries_.empty()) std::cout<<"None\n"; for(const auto& x:beneficiaries_) displayPolymorphic(x);
}
void DonationSystem::searchRecord() const {
    std::cout<<"Search: 1 Donor ID, 2 Campaign ID, 3 Donation ID, 4 Beneficiary ID\n"; int type=readInt("Type: "), id=readInt("ID: "); bool found=false;
    if(type==1) for(const auto& x:donors_) if(x.id==id){displayPolymorphic(x);found=true;}
    if(type==2) for(const auto& x:campaigns_) if(x.id==id){displayPolymorphic(x);found=true;}
    if(type==3) for(const auto& x:donations_) if(x.id==id){displayPolymorphic(x);found=true;}
    if(type==4) for(const auto& x:beneficiaries_) if(x.id==id){displayPolymorphic(x);found=true;}
    if(!found) std::cout<<"No matching record found.\n";
}
void DonationSystem::updateRecord() {
    std::cout<<"Update: 1 Donor phone, 2 Campaign target, 3 Beneficiary need\n"; int type=readInt("Type: "), id=readInt("ID: ");
    if(type==1){auto d=findDonor(id); if(!d){std::cout<<"Donor not found.\n";return;} d->phone=readLine("New phone: "); std::cout<<"Donor updated.\n";}
    else if(type==2){auto c=findCampaign(id); if(!c){std::cout<<"Campaign not found.\n";return;} double t=readAmount("New target (Rs): "); if(t<c->collected) std::cout<<"Note: target is below amount already collected.\n"; c->target=t; std::cout<<"Campaign updated.\n";}
    else if(type==3){auto it=std::find_if(beneficiaries_.begin(),beneficiaries_.end(),[id](const Beneficiary& b){return b.id==id;}); if(it==beneficiaries_.end()){std::cout<<"Beneficiary not found.\n";return;} it->need=readLine("New need / purpose: "); std::cout<<"Beneficiary updated.\n";}
    else std::cout<<"Unknown type.\n";
}
void DonationSystem::deleteRecord() {
    std::cout<<"Delete: 1 Donor, 2 Campaign, 3 Beneficiary\n"; int type=readInt("Type: "), id=readInt("ID: ");
    if(type==1){ if(std::any_of(donations_.begin(),donations_.end(),[id](const Donation& d){return d.donorId==id;})){std::cout<<"Cannot delete donor with donation history.\n";return;} auto old=donors_.size(); std::erase_if(donors_,[id](const Donor& d){return d.id==id;}); if(old==donors_.size())std::cout<<"Donor not found.\n";else std::cout<<"Donor deleted.\n"; }
    else if(type==2){ if(std::any_of(donations_.begin(),donations_.end(),[id](const Donation& d){return d.campaignId==id;})){std::cout<<"Cannot delete campaign with donation history.\n";return;} auto old=campaigns_.size(); std::erase_if(campaigns_,[id](const Campaign& c){return c.id==id;}); if(old==campaigns_.size())std::cout<<"Campaign not found.\n";else std::cout<<"Campaign deleted.\n"; }
    else if(type==3){auto old=beneficiaries_.size(); std::erase_if(beneficiaries_,[id](const Beneficiary& b){return b.id==id;}); if(old==beneficiaries_.size())std::cout<<"Beneficiary not found.\n";else std::cout<<"Beneficiary deleted.\n";}
    else std::cout<<"Unknown type.\n";
}
void DonationSystem::recordDonation() {
    if(donors_.empty()||campaigns_.empty()){std::cout<<"Add at least one donor and campaign first.\n";return;}
    std::cout<<"Available donors:\n"; for(const auto& d:donors_)d.display(); int did=readInt("Donor ID: "); auto donor=findDonor(did); if(!donor){std::cout<<"Donor not found.\n";return;}
    std::cout<<"Available campaigns:\n"; for(const auto& c:campaigns_)c.display(); int cid=readInt("Campaign ID: "); auto campaign=findCampaign(cid); if(!campaign){std::cout<<"Campaign not found.\n";return;}
    double amount=readAmount("Donation amount (Rs): "); auto date=readLine("Date (YYYY-MM-DD): "); if(date.empty()) throw std::invalid_argument("Date cannot be empty.");
    // Main transaction: validate, create donation, update campaign total, and persist.
    campaign->addDonation(amount); donations_.emplace_back(nextDonationId_++,did,cid,amount,date);
    std::cout<<"Donation recorded successfully. Receipt ID: "<<donations_.back().id<<'\n';
    if(!files_.save(donors_,campaigns_,donations_,beneficiaries_)) std::cout<<"Warning: donation is in memory, but automatic save failed.\n";
}
void DonationSystem::report() const {
    double total=0; for(const auto& d:donations_)total+=d.amount;
    std::cout<<"\n=== DONATION REPORT ===\nDonors: "<<donors_.size()<<"\nCampaigns: "<<campaigns_.size()<<"\nDonations: "<<donations_.size()<<"\nBeneficiaries: "<<beneficiaries_.size()<<"\nTotal donations: Rs "<<std::fixed<<std::setprecision(2)<<total<<"\n";
    for(const auto& c:campaigns_)c.display();
}
void DonationSystem::saveLoad() {
    std::cout<<"1 Save current data\n2 Load saved data (replaces current in-memory records)\n"; int c=readInt("Choose: ");
    if(c==1) std::cout<<(files_.save(donors_,campaigns_,donations_,beneficiaries_)?"Saved successfully.\n":"Save failed. Check write permissions.\n");
    else if(c==2){ donors_.clear();campaigns_.clear();donations_.clear();beneficiaries_.clear(); if(files_.load(donors_,campaigns_,donations_,beneficiaries_)) std::cout<<"Loaded saved records.\n"; else std::cout<<"No saved records found.\n"; }
    else std::cout<<"Unknown option.\n";
}
