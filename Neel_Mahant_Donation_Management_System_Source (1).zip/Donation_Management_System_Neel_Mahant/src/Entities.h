#pragma once
#include <iostream>
#include <string>

class Displayable {
public:
    virtual ~Displayable() = default;
    virtual void display() const = 0;
};

class Donor : public Displayable {
public:
    int id{}; std::string name, phone;
    Donor() = default;
    Donor(int donorId, std::string donorName, std::string donorPhone);
    void display() const override;
};

class Campaign : public Displayable {
public:
    int id{}; std::string name; double target{}, collected{};
    Campaign() = default;
    Campaign(int campaignId, std::string campaignName, double campaignTarget, double totalCollected = 0.0);
    double progress() const;
    void addDonation(double amount);
    void display() const override;
};

class Donation : public Displayable {
public:
    int id{}, donorId{}, campaignId{}; double amount{}; std::string date;
    Donation() = default;
    Donation(int donationId, int donor, int campaign, double donationAmount, std::string donationDate);
    void display() const override;
};

class Beneficiary : public Displayable {
public:
    int id{}; std::string name, need; double amountReceived{};
    Beneficiary() = default;
    Beneficiary(int beneficiaryId, std::string beneficiaryName, std::string beneficiaryNeed, double received = 0.0);
    void receiveAid(double amount);
    void display() const override;
};
