#pragma once
#include "Entities.h"
#include "FileManager.h"
#include <vector>

class DonationSystem {
public:
    DonationSystem();
    void run();
    void addRecord();
    void displayRecords() const;
    void searchRecord() const;
    void updateRecord();
    void deleteRecord();
    void recordDonation();
    void report() const;
    void saveLoad();
private:
    std::vector<Donor> donors_;
    std::vector<Campaign> campaigns_;
    std::vector<Donation> donations_;
    std::vector<Beneficiary> beneficiaries_;
    FileManager files_;
    int nextDonorId_{1}, nextCampaignId_{1}, nextDonationId_{1}, nextBeneficiaryId_{1};
    void seedIfEmpty();
    int readInt(const std::string& prompt) const;
    double readAmount(const std::string& prompt) const;
    std::string readLine(const std::string& prompt) const;
    Donor* findDonor(int id);
    Campaign* findCampaign(int id);
    void displayPolymorphic(const Displayable& item) const;
};
