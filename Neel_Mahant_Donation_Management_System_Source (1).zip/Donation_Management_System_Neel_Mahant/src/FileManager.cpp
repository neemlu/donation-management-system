#include "FileManager.h"
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <utility>

FileManager::FileManager(std::string directory) : directory_(std::move(directory)) {}

bool FileManager::save(const std::vector<Donor>& donors, const std::vector<Campaign>& campaigns,
                       const std::vector<Donation>& donations, const std::vector<Beneficiary>& beneficiaries) const {
    try { std::filesystem::create_directories(directory_); } catch (...) { return false; }
    std::ofstream d(directory_ + "/donors.txt"), c(directory_ + "/campaigns.txt"), n(directory_ + "/donations.txt"), b(directory_ + "/beneficiaries.txt");
    if (!d || !c || !n || !b) return false;
    for (const auto& x : donors) d << x.id << ' ' << std::quoted(x.name) << ' ' << std::quoted(x.phone) << '\n';
    for (const auto& x : campaigns) c << x.id << ' ' << std::quoted(x.name) << ' ' << std::setprecision(17) << x.target << ' ' << x.collected << '\n';
    for (const auto& x : donations) n << x.id << ' ' << x.donorId << ' ' << x.campaignId << ' ' << std::setprecision(17) << x.amount << ' ' << std::quoted(x.date) << '\n';
    for (const auto& x : beneficiaries) b << x.id << ' ' << std::quoted(x.name) << ' ' << std::quoted(x.need) << ' ' << std::setprecision(17) << x.amountReceived << '\n';
    return d.good() && c.good() && n.good() && b.good();
}

bool FileManager::load(std::vector<Donor>& donors, std::vector<Campaign>& campaigns,
                       std::vector<Donation>& donations, std::vector<Beneficiary>& beneficiaries) const {
    bool any = false; std::string name, phone, need, date; int id, donorId, campaignId; double target, collected, amount;
    { std::ifstream f(directory_ + "/donors.txt"); while (f >> id >> std::quoted(name) >> std::quoted(phone)) { donors.emplace_back(id,name,phone); any=true; } }
    { std::ifstream f(directory_ + "/campaigns.txt"); while (f >> id >> std::quoted(name) >> target >> collected) { campaigns.emplace_back(id,name,target,collected); any=true; } }
    { std::ifstream f(directory_ + "/donations.txt"); while (f >> id >> donorId >> campaignId >> amount >> std::quoted(date)) { donations.emplace_back(id,donorId,campaignId,amount,date); any=true; } }
    { std::ifstream f(directory_ + "/beneficiaries.txt"); while (f >> id >> std::quoted(name) >> std::quoted(need) >> amount) { beneficiaries.emplace_back(id,name,need,amount); any=true; } }
    return any;
}
