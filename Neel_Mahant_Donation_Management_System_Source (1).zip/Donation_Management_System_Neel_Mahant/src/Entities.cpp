#include "Entities.h"
#include <iomanip>
#include <stdexcept>
#include <utility>

Donor::Donor(int donorId, std::string donorName, std::string donorPhone)
    : id(donorId), name(std::move(donorName)), phone(std::move(donorPhone)) {}
void Donor::display() const { std::cout << "Donor #" << id << " | " << name << " | Phone: " << phone << '\n'; }

Campaign::Campaign(int campaignId, std::string campaignName, double campaignTarget, double totalCollected)
    : id(campaignId), name(std::move(campaignName)), target(campaignTarget), collected(totalCollected) {}
double Campaign::progress() const { return target > 0 ? (collected / target) * 100.0 : 0.0; }
void Campaign::addDonation(double amount) { if (amount <= 0) throw std::invalid_argument("Amount must be positive."); collected += amount; }
void Campaign::display() const { std::cout << "Campaign #" << id << " | " << name << " | Target: Rs " << std::fixed << std::setprecision(2) << target << " | Collected: Rs " << collected << " | Progress: " << progress() << "%\n"; }

Donation::Donation(int donationId, int donor, int campaign, double donationAmount, std::string donationDate)
    : id(donationId), donorId(donor), campaignId(campaign), amount(donationAmount), date(std::move(donationDate)) {}
void Donation::display() const { std::cout << "Donation #" << id << " | Donor #" << donorId << " | Campaign #" << campaignId << " | Rs " << std::fixed << std::setprecision(2) << amount << " | Date: " << date << '\n'; }

Beneficiary::Beneficiary(int beneficiaryId, std::string beneficiaryName, std::string beneficiaryNeed, double received)
    : id(beneficiaryId), name(std::move(beneficiaryName)), need(std::move(beneficiaryNeed)), amountReceived(received) {}
void Beneficiary::receiveAid(double amount) { if (amount <= 0) throw std::invalid_argument("Aid amount must be positive."); amountReceived += amount; }
void Beneficiary::display() const { std::cout << "Beneficiary #" << id << " | " << name << " | Need: " << need << " | Aid received: Rs " << std::fixed << std::setprecision(2) << amountReceived << '\n'; }
