# Manual test cases (15)

Record the actual output and Pass/Fail after running your build. Start with a clean `data/` folder for repeatability; back it up before deleting anything.

| ID | Operation / Input | Expected result |
|---|---|---|
| T01 | Start program with no saved files | Menu appears; starter campaign is available |
| T02 | Add donor with name and phone | Donor is created with a unique ID |
| T03 | Add campaign with positive target | Campaign is created |
| T04 | Add beneficiary with name and need | Beneficiary is created |
| T05 | Display records | Lists all existing record categories |
| T06 | Search for an existing donor ID | Matching donor is displayed |
| T07 | Search for a nonexistent ID | “No matching record found.” |
| T08 | Update an existing donor phone | New phone is displayed on next view |
| T09 | Update a campaign target | Target changes; warning appears if below collected total |
| T10 | Delete an unreferenced beneficiary | Beneficiary is removed |
| T11 | Record a donation with valid donor/campaign/amount/date | Donation receipt ID appears and campaign collected total increases |
| T12 | Record donation using unknown donor ID | Operation is cancelled without creating donation |
| T13 | Enter zero or negative donation amount | Validation asks for a positive amount |
| T14 | Save, exit, restart | Existing records are loaded from text files |
| T15 | Delete donor/campaign with donation history | Deletion is refused to preserve history |
