# Donation Management System — CPP38

**Student:** Neel Mahant  
**Enrollment No.:** IU2541230059  
**Course/project:** CPP38 — C++ Guided Project

A console-based C++ object-oriented donation tracker based on the supplied project blueprint.

## Features
- Add donors, campaigns, and beneficiaries
- Display all records and search by record ID
- Update donor phone, campaign target, or beneficiary need
- Delete donors/campaigns/beneficiaries when referential history allows it
- Record donations, update campaign totals, and issue a receipt ID
- Summary report and campaign progress
- Text-file persistence in `data/`; records are loaded on startup and saved on exit and after donations
- Input validation, exception handling, constructors/destructors, inheritance and runtime polymorphism

## Requirements
A C++20 compiler (GCC 11+, Clang 13+, or a recent Visual Studio compiler) and standard library filesystem support.

## Build
From the project root:

```bash
g++ -std=c++20 -Wall -Wextra -pedantic src/main.cpp src/Entities.cpp src/FileManager.cpp src/DonationSystem.cpp -o donation_system
```

Run:

```bash
./donation_system
```

Windows (MinGW):

```powershell
g++ -std=c++20 -Wall -Wextra -pedantic src/main.cpp src/Entities.cpp src/FileManager.cpp src/DonationSystem.cpp -o donation_system.exe
.\donation_system.exe
```

Run the executable from the project root so the relative `data/` folder is consistent. The program creates the folder and four data files as needed. Do not edit the data files while the program is running.

## Menu
1. Add Record  2. Display Records  3. Search Record  4. Update Record  5. Delete Record  6. Record Donation  7. Report  8. Save / Load  9. Exit

The starter campaign is created automatically when no campaign data exists. Add a donor before recording a donation.

## UML sources
PlantUML source files are in `UML/`. Open them with a PlantUML-compatible viewer or extension to render the diagrams for the report.

## Test plan
See `tests/test-cases.md`. Run the cases manually in the console and record actual outputs before submission. The expected outcomes are not a claim that all 15 cases have already been executed.

## Important notes
- This is an educational prototype, not a production donation/payment platform. It does not process real payments or verify donor identity.
- The data files use quoted text fields; keep backups before manually changing them.
- Review and understand the source before your viva/submission. Update the report with your actual compiler, screenshots, test results, and any changes you make.
